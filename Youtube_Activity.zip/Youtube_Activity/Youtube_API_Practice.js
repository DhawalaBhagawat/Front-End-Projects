var text_value = "";

// Get the input from the text box
function get_text_value(){
text_value = $("#text_input").val()
  console.log(text_value);
  getVideo();
}

// function to call youtube API
function getVideo() {
      $.ajax({
        type: 'GET',
        url: 'https://www.googleapis.com/youtube/v3/search',
        data: {
            key: 'your api key',
            q: text_value,
            part: 'snippet',
            maxResults: 1,
            type: 'video',
            videoEmbeddable: true,
        },
        success: function(data){
            embedVideo(data)
        },
        error: function(response){
            console.log("Request Failed");
        }
      });
    }
// Display result back to the browser
    function embedVideo(data) {
    $('iframe').attr('src', 'https://www.youtube.com/embed/' + data.items[0].id.videoId)
    $('h3').text(data.items[0].snippet.title)
    $('.description').text(data.items[0].snippet.description)
    $('#show_result').show()
    $('#input_value').hide()
}
